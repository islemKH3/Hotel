/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package applicationhôtel;

import static java.lang.Character.isLetter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;



public class ApplicationHôtel {
    
    public  static boolean num(String s){
        for (int i=0;i<s.length();i++){
            if (isLetter(s.charAt(i)))
                return(false);  
            
        }
        return(true);
    }
    
    public static Connection connectBD()
    {
        try {
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/systeme_hotel?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "root");
            return con;
        } catch (SQLException ex) {
            Logger.getLogger(ApplicationHôtel.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null,"Not Connected");
            return null;
        }
    }
    public static void main(String[] args) {
        
        new Acceuil().setVisible(true);
    }
}
