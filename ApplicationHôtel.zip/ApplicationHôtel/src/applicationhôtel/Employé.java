/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package applicationhôtel;

/**
 *
 * @author kheli_z5cuz9z
 */
public class Employé {
    private int id;
    private String nom;
    private String prènom;
    private String mdp;
    
    public Employé (int id, String nom, String prènom, String mdp)
    {
        this.id=id;
        this.nom=nom;
        this.prènom=prènom;
        this.mdp=mdp;
    }
    
    public int getId ()
    {
        return(this.id);
    }
    
    public void setCin(int id)
    {
        this.id=id;
    }
    
    public String getNom()
    {
        return(this.nom);
    }
    
    public void setNom(String nom)
    {
        this.nom=nom;
    }
    
    public String getPrènom()
    {
        return (this.prènom);
    }
    
    public void setPrènom(String prènom)
    {
        this.prènom=prènom;
    }
    
    public String getMdp()
    {
        return(this.mdp);
    }
    
    public void setMdp(String mdp)
    {
        this.mdp=mdp;
    }
}
